# BunnyGang DNS

An initial Android app prototype that measures DNS-over-HTTPS endpoint response time with three requests and reports the median. It does **not** change Android's system-wide DNS and does not promise lower in-game ping.

## Build on GitHub Actions

1. Upload the contents of this folder to the root of your GitHub repository, keeping `.github/workflows/build.yml` in place.
2. Open the **Actions** tab and select **Build BunnyGang DNS APK**.
3. Press **Run workflow** (or wait for the first push workflow to finish).
4. Open the completed run and download `BunnyGang-DNS-debug-apk` from **Artifacts**.

This is a debug APK for testing, not a Play Store release. The YouTube handle in About should be checked by the owner before release.
