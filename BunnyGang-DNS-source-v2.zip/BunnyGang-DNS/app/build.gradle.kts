plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bunnygang.dns"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bunnygang.dns"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-alpha"
    }
}
