package com.bunnygang.dns

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private var english = false
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var custom: EditText
    private val providers = listOf(
        Provider("Cloudflare", "https://cloudflare-dns.com/dns-query"),
        Provider("Google", "https://dns.google/resolve"),
        Provider("Quad9", "https://dns.quad9.net:5053/dns-query"),
        Provider("AdGuard", "https://dns.adguard-dns.com/resolve")
    )
    data class Provider(val name: String, val endpoint: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(13, 20, 35))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "BunnyGang DNS"; textSize = 26f; setTextColor(Color.WHITE); setTypeface(null, 1) }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val lang = Button(this).apply { text = if (english) "فارسی" else "EN"; setOnClickListener { english = !english; render() } }
        top.addView(lang)
        root.addView(top)
        addText(if (english) "Test DNS-over-HTTPS response time" else "تست زمان پاسخ DNS از طریق HTTPS", 15f, Color.LTGRAY, 12)
        status = addText(if (english) "Ready to test" else "آماده‌ی آزمایش", 16f, Color.rgb(100, 220, 170), 18)
        addText(if (english) "Choose a provider" else "یک سرویس‌دهنده انتخاب کن", 18f, Color.WHITE, 8, true)
        providers.forEach { p ->
            val b = Button(this).apply {
                text = p.name
                isAllCaps = false
                setOnClickListener { test(p.name, p.endpoint) }
            }
            root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }
        addText(if (english) "Custom DoH endpoint" else "آدرس سفارشی DoH", 17f, Color.WHITE, 12, true)
        custom = EditText(this).apply {
            hint = "https://example.com/dns-query"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
        }
        root.addView(custom, LinearLayout.LayoutParams(-1, -2))
        val customButton = Button(this).apply {
            text = if (english) "Test custom endpoint" else "آزمایش آدرس سفارشی"
            setOnClickListener {
                val endpoint = custom.text.toString().trim()
                if (!endpoint.startsWith("https://")) {
                    status.text = if (english) "Enter a valid HTTPS endpoint" else "یک آدرس HTTPS معتبر وارد کن"
                } else test(if (english) "Custom" else "سفارشی", endpoint)
            }
        }
        root.addView(customButton)
        result = addText(if (english) "Results will appear here." else "نتیجه‌ی آزمایش اینجا نمایش داده می‌شود.", 14f, Color.WHITE, 12)
        addText(if (english) "Note: This tests DoH response time only. It does not change Android's system DNS or guarantee lower game ping." else "نکته: این برنامه فعلاً فقط زمان پاسخ DoH را آزمایش می‌کند؛ DNS کل گوشی را تغییر نمی‌دهد و کاهش پینگ بازی را تضمین نمی‌کند.", 13f, Color.LTGRAY, 20)
        addText(if (english) "About" else "درباره برنامه", 18f, Color.WHITE, 8, true)
        addText("BunnyGang DNS\nBunnyGang × ChatGPT\nYouTube: youtube.com/@bunnygang10", 13f, Color.LTGRAY, 4)
    }

    private fun addText(value: String, size: Float, color: Int, top: Int, bold: Boolean = false): TextView {
        val t = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, 1)
        }
        root.addView(t, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(4) })
        return t
    }

    private fun test(name: String, endpoint: String) {
        status.text = if (english) "Testing $name…" else "در حال آزمایش $name…"
        result.text = ""
        thread {
            val samples = mutableListOf<Long>()
            var error = ""
            repeat(3) {
                try {
                    val separator = if (endpoint.contains("?")) "&" else "?"
                    val url = URL(endpoint + separator + "name=example.com&type=A")
                    val start = System.nanoTime()
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 6000; readTimeout = 6000; requestMethod = "GET"
                        setRequestProperty("Accept", "application/dns-json")
                    }
                    val code = conn.responseCode
                    val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                    val elapsed = (System.nanoTime() - start) / 1_000_000
                    if (code in 200..299 && body.isNotBlank()) {
                        // Some DoH JSON endpoints return a Status field; Cloudflare's JSON endpoint is also supported.
                        try { JSONObject(body) } catch (_: Exception) { }
                        samples.add(elapsed)
                    } else error = "HTTP $code"
                    conn.disconnect()
                } catch (e: Exception) { error = e.message ?: "Network error" }
            }
            runOnUiThread {
                if (samples.isNotEmpty()) {
                    val sorted = samples.sorted()
                    val median = sorted[sorted.size / 2]
                    status.text = if (english) "$name test completed" else "آزمایش $name تمام شد"
                    result.text = (if (english) "Successful requests: ${samples.size}/3\nMedian response time: ${median} ms\nSamples: ${samples.joinToString(" / ")} ms" else "درخواست موفق: ${samples.size}/3\nمیانه زمان پاسخ: ${median} میلی‌ثانیه\nنمونه‌ها: ${samples.joinToString(" / ")} میلی‌ثانیه") + if (error.isNotBlank()) "\n$error" else ""
                } else {
                    status.text = if (english) "Test failed" else "آزمایش ناموفق بود"
                    result.text = if (english) "Could not reach this endpoint. Check the URL and connection.\n$error" else "اتصال به این آدرس ممکن نشد. آدرس و اینترنت را بررسی کن.\n$error"
                }
            }
        }
    }
}
